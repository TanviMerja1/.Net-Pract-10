using StudentApi.Middleware;
using StudentApi.Services;

var builder = WebApplication.CreateBuilder(args);

// ---------- Services (dependency injection) ----------
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<IStudentService, StudentService>();
builder.Services.AddSingleton<RequestLogStore>();

var app = builder.Build();

// ---------- Middleware pipeline (order matters) ----------
app.UseMiddleware<RequestLoggingMiddleware>();       // 1. log every request (outermost)
app.UseMiddleware<ExceptionHandlingMiddleware>();    // 2. turn exceptions into JSON errors

app.UseSwagger();                                    // 3. Swagger JSON
app.UseSwaggerUI();                                  //    Swagger page: /swagger

// Open Swagger when the site root is visited
app.MapGet("/", () => Results.Redirect("/swagger"));

// Shows the requests recorded by the logging middleware (open in Chrome)
app.MapGet("/api/logs", (RequestLogStore store) => store.GetAll());

// Demo endpoint to prove the exception middleware works
app.MapGet("/api/error", () =>
{
    throw new InvalidOperationException("This is a test exception.");
#pragma warning disable CS0162
    return Results.Ok();
#pragma warning restore CS0162
});

app.MapControllers();                                // 4. endpoints

app.Run();
