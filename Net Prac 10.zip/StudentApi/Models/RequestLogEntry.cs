namespace StudentApi.Models;

/// <summary>One entry written by the request-logging middleware.</summary>
public class RequestLogEntry
{
    public DateTime Time { get; set; }
    public string Method { get; set; } = string.Empty;
    public string Path { get; set; } = string.Empty;
    public int StatusCode { get; set; }
    public long ElapsedMs { get; set; }
}
