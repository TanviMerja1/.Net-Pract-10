namespace StudentApi.Models;

/// <summary>Student entity stored by the service.</summary>
public class Student
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string Branch { get; set; } = string.Empty;
    public int Semester { get; set; }
    public decimal Cgpa { get; set; }
    public DateTime CreatedOn { get; set; }
}
