# Experiment 10 – Student Management REST API (ASP.NET Core 8)

## Run (opens in Chrome)
Open StudentApi.sln in Visual Studio 2022 and press F5.
Chrome opens Swagger UI at http://localhost:5100/swagger where every endpoint can be tested.
(Set Chrome: Run dropdown -> Browse With... -> Google Chrome -> Set as Default.)

## Project structure
- Controllers/  – StudentsController (REST endpoints)
- Models/       – Student, RequestLogEntry
- Dtos/         – StudentDto (validation rules)
- Services/     – IStudentService, StudentService (in-memory), RequestLogStore
- Middleware/   – RequestLoggingMiddleware, ExceptionHandlingMiddleware
- Program.cs    – DI setup + middleware pipeline

## Endpoints
GET    /api/students[?branch=CE&search=aar]
GET    /api/students/{id}
POST   /api/students
PUT    /api/students/{id}
DELETE /api/students/{id}
GET    /api/logs    – requests recorded by the logging middleware
GET    /api/error   – throws an exception to demo the exception middleware

Sample POST body:
{ "name": "Rahul Shah", "email": "rahul@example.com", "branch": "IT", "semester": 4, "cgpa": 8.1 }

## Push to GitHub
git init
git add .
git commit -m "Ex-10 Student REST API"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
