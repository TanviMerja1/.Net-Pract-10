using System.Diagnostics;
using StudentApi.Models;
using StudentApi.Services;

namespace StudentApi.Middleware;

/// <summary>
/// Custom middleware #1: measures how long each request takes, adds an X-Elapsed-Ms header
/// and records the request (method, path, status, time) in the RequestLogStore.
/// </summary>
public class RequestLoggingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<RequestLoggingMiddleware> _logger;
    private readonly RequestLogStore _store;

    public RequestLoggingMiddleware(RequestDelegate next, ILogger<RequestLoggingMiddleware> logger, RequestLogStore store)
    {
        _next = next;
        _logger = logger;
        _store = store;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        // Do not log Swagger UI files
        if (context.Request.Path.StartsWithSegments("/swagger"))
        {
            await _next(context);
            return;
        }

        var watch = Stopwatch.StartNew();

        // Add response header just before the response starts
        context.Response.OnStarting(() =>
        {
            context.Response.Headers["X-Elapsed-Ms"] = watch.ElapsedMilliseconds.ToString();
            return Task.CompletedTask;
        });

        await _next(context);   // call the next middleware in the pipeline

        watch.Stop();
        var entry = new RequestLogEntry
        {
            Time = DateTime.Now,
            Method = context.Request.Method,
            Path = context.Request.Path + context.Request.QueryString,
            StatusCode = context.Response.StatusCode,
            ElapsedMs = watch.ElapsedMilliseconds
        };
        _store.Add(entry);
        _logger.LogInformation("{Method} {Path} -> {Status} in {Ms} ms",
            entry.Method, entry.Path, entry.StatusCode, entry.ElapsedMs);
    }
}
