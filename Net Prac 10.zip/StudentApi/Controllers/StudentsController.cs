using Microsoft.AspNetCore.Mvc;
using StudentApi.Dtos;
using StudentApi.Models;
using StudentApi.Services;

namespace StudentApi.Controllers;

/// <summary>REST endpoints for student CRUD: /api/students</summary>
[ApiController]
[Route("api/[controller]")]
public class StudentsController : ControllerBase
{
    private readonly IStudentService _service;

    public StudentsController(IStudentService service) => _service = service;

    // GET /api/students?branch=CE&search=aar
    [HttpGet]
    public ActionResult<IEnumerable<Student>> GetAll([FromQuery] string? branch, [FromQuery] string? search)
        => Ok(_service.GetAll(branch, search));

    // GET /api/students/1
    [HttpGet("{id:int}")]
    public ActionResult<Student> GetById(int id)
    {
        var s = _service.GetById(id);
        return s == null ? NotFound(new { message = $"Student {id} not found" }) : Ok(s);
    }

    // POST /api/students
    [HttpPost]
    public ActionResult<Student> Create([FromBody] StudentDto dto)
    {
        var created = _service.Create(dto);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);   // 201
    }

    // PUT /api/students/1
    [HttpPut("{id:int}")]
    public ActionResult<Student> Update(int id, [FromBody] StudentDto dto)
    {
        var updated = _service.Update(id, dto);
        return updated == null ? NotFound(new { message = $"Student {id} not found" }) : Ok(updated);
    }

    // DELETE /api/students/1
    [HttpDelete("{id:int}")]
    public IActionResult Delete(int id)
        => _service.Delete(id) ? NoContent() : NotFound(new { message = $"Student {id} not found" });   // 204
}
