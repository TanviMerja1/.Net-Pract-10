using System.ComponentModel.DataAnnotations;

namespace StudentApi.Dtos;

/// <summary>Request body used for POST (create) and PUT (update). Validated automatically.</summary>
public class StudentDto
{
    [Required, StringLength(100, MinimumLength = 2)]
    public string Name { get; set; } = string.Empty;

    [Required, EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required, StringLength(50)]
    public string Branch { get; set; } = string.Empty;

    [Range(1, 8, ErrorMessage = "Semester must be between 1 and 8")]
    public int Semester { get; set; }

    [Range(0, 10, ErrorMessage = "CGPA must be between 0 and 10")]
    public decimal Cgpa { get; set; }
}
