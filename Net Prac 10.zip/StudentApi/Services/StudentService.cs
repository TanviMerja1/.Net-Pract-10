using StudentApi.Dtos;
using StudentApi.Models;

namespace StudentApi.Services;

/// <summary>In-memory student store (thread-safe). Registered as a singleton.</summary>
public class StudentService : IStudentService
{
    private readonly List<Student> _students = new();
    private readonly object _lock = new();
    private int _nextId = 1;

    public StudentService()
    {
        // Seed data
        Create(new StudentDto { Name = "Aarav Patel",   Email = "aarav@example.com", Branch = "CE",  Semester = 5, Cgpa = 8.7m });
        Create(new StudentDto { Name = "Diya Shah",     Email = "diya@example.com",  Branch = "CE",  Semester = 5, Cgpa = 9.1m });
        Create(new StudentDto { Name = "Isha Joshi",    Email = "isha@example.com",  Branch = "IT",  Semester = 3, Cgpa = 8.2m });
        Create(new StudentDto { Name = "Yash Parmar",   Email = "yash@example.com",  Branch = "ECE", Semester = 7, Cgpa = 7.2m });
    }

    public IEnumerable<Student> GetAll(string? branch, string? search)
    {
        lock (_lock)
        {
            IEnumerable<Student> q = _students;
            if (!string.IsNullOrWhiteSpace(branch))
                q = q.Where(s => s.Branch.Equals(branch, StringComparison.OrdinalIgnoreCase));
            if (!string.IsNullOrWhiteSpace(search))
                q = q.Where(s => s.Name.Contains(search, StringComparison.OrdinalIgnoreCase));
            return q.OrderBy(s => s.Id).ToList();
        }
    }

    public Student? GetById(int id)
    {
        lock (_lock) return _students.FirstOrDefault(s => s.Id == id);
    }

    public Student Create(StudentDto dto)
    {
        lock (_lock)
        {
            var s = new Student
            {
                Id = _nextId++,
                Name = dto.Name,
                Email = dto.Email,
                Branch = dto.Branch,
                Semester = dto.Semester,
                Cgpa = dto.Cgpa,
                CreatedOn = DateTime.Now
            };
            _students.Add(s);
            return s;
        }
    }

    public Student? Update(int id, StudentDto dto)
    {
        lock (_lock)
        {
            var s = _students.FirstOrDefault(x => x.Id == id);
            if (s == null) return null;
            s.Name = dto.Name;
            s.Email = dto.Email;
            s.Branch = dto.Branch;
            s.Semester = dto.Semester;
            s.Cgpa = dto.Cgpa;
            return s;
        }
    }

    public bool Delete(int id)
    {
        lock (_lock) return _students.RemoveAll(s => s.Id == id) > 0;
    }
}
