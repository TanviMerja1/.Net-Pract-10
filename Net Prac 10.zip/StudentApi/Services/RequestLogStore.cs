using System.Collections.Concurrent;
using StudentApi.Models;

namespace StudentApi.Services;

/// <summary>Keeps the last 50 request log entries so they can be viewed in the browser at /api/logs.</summary>
public class RequestLogStore
{
    private const int MaxEntries = 50;
    private readonly ConcurrentQueue<RequestLogEntry> _entries = new();

    public void Add(RequestLogEntry entry)
    {
        _entries.Enqueue(entry);
        while (_entries.Count > MaxEntries) _entries.TryDequeue(out _);
    }

    public IEnumerable<RequestLogEntry> GetAll() => _entries.Reverse().ToList();   // newest first
}
