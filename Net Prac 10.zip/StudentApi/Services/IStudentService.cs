using StudentApi.Dtos;
using StudentApi.Models;

namespace StudentApi.Services;

public interface IStudentService
{
    IEnumerable<Student> GetAll(string? branch, string? search);
    Student? GetById(int id);
    Student Create(StudentDto dto);
    Student? Update(int id, StudentDto dto);
    bool Delete(int id);
}
